import 'package:flutter/material.dart';
import 'package:login_signup/appAssets/assets.dart';
import 'package:login_signup/firebase_auth/auth.dart';
import 'package:login_signup/res/res.dart';
import 'package:login_signup/routes/routes.dart';
import 'package:provider/provider.dart';
import 'package:login_signup/providers/profile_provider.dart';
import 'package:login_signup/screens/dashboard/profile_screen.dart';

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key});

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final profileProvider =
          Provider.of<ProfileProvider>(context, listen: false);
      profileProvider.fetchProfile();
    });
  }

  @override
  Widget build(BuildContext context) {
    final profileProvider = Provider.of<ProfileProvider>(context);
    const Color pinkColor = Color.fromARGB(255, 142, 35, 67);
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: profileProvider.isLoading
              ? const Center(child: CircularProgressIndicator(color: pinkColor,))
              : profileProvider.profile == null
                  ? const Center(child: Text("No profile data available"))
                  : Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        // Profile Row with Picture and Text
                        Row(
                          children: [
                            // Profile Picture
                            CircleAvatar(
                              radius: 30,
                              backgroundImage: profileProvider
                                          .profile?.profileImage !=
                                      null
                                  ? FileImage(
                                      profileProvider.profile!.profileImage!)
                                  : const AssetImage(Assets.avatar)
                                      as ImageProvider,
                            ),
                            const SizedBox(width: 12),

                            // Greeting and Name
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                const Text(
                                  'Hey 👋',
                                  style: TextStyle(
                                    color: Colors.black,
                                    fontSize: 18,
                                  ),
                                ),
                                Text(
                                  "${profileProvider.profile!.firstName} ${profileProvider.profile!.lastName}",
                                  style: const TextStyle(
                                    color: Colors.black,
                                    fontWeight: FontWeight.bold,
                                    fontSize: 22,
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),

                        const SizedBox(height: 20),

                        // Navigate to Profile Screen Button
                        Center(
                          child: Column(
                            children: [
                              ElevatedButton(
                                onPressed: () {
                                  Navigator.of(context).push(MaterialPageRoute(
                                    builder: (context) => ProfileScreen(),
                                  ));
                                },
                                style: ElevatedButton.styleFrom(
                                  backgroundColor: pinkColor,
                                  padding: const EdgeInsets.symmetric(
                                      vertical: 15, horizontal: 90),
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(15),
                                  ),
                                ),
                                child: const Text('Manage my Profile',
                                    style: TextStyle(
                                        color: Colors.white, fontSize: 16)),
                              ),
                              SizedBox(height: getHeight() * 0.005),
                              ElevatedButton(
                                onPressed: () {
                                  Auth().signOut();
                                  router.go(Routes.onLoginRoute);
                                },
                                style: ElevatedButton.styleFrom(
                                  backgroundColor: Colors.white,
                                  padding: const EdgeInsets.symmetric(
                                      vertical: 15, horizontal: 130),
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(15),
                                  ),
                                ),
                                child: const Text('Logout',
                                    style: TextStyle(
                                        color: Colors.black, fontSize: 16)),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
        ),
      ),
    );
  }
}
