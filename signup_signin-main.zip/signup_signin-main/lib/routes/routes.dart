import 'package:go_router/go_router.dart';
import 'package:login_signup/screens/authentication/login_screen.dart';
import 'package:login_signup/screens/authentication/register_screen.dart';
import 'package:login_signup/screens/dashboard/dashboard.dart';
import 'package:login_signup/screens/dashboard/profile_screen.dart';
//import 'package:login_signup/screens/dashboard/profile_screen.dart';
import 'package:login_signup/screens/splash/splash_screen.dart';

class Routes {
  static const String initialRoute = '/';
  static const String onBoardingRoute = '/on_boarding';
  static const String onRegisterRoute = '/register_screen';
  static const String onLoginRoute = '/login_screen';
  static const String onDashboard = '/dashboard_screen';
  static const String onProfileScreen = '/profile_screen';
}


final GoRouter router = GoRouter(
  //initialLocation: Routes.onDashboard,
  routes: [
    
    GoRoute(
      path: '/',
      builder: (context, state) => const SplashScreen(),
    ),
    GoRoute(
        path: '/register_screen',
        builder: (context, state) => const RegisterScreen()),
        GoRoute(path: '/login_screen',
        builder: (context, state) => const LoginScreen(),),
        GoRoute(path: '/profile_screen',
        builder: (context, state) => const ProfileScreen(),),
         GoRoute(path: '/dashboard_screen',
        builder: (context, state) => const DashboardScreen(),)
  ],
);
